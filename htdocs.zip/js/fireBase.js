var app_fireBase = {};
(function(){
	
	var config = {
    apiKey: "AIzaSyAiaNcXbUMTKBEx6uUx0Gha6qgndadxkzI",
    authDomain: "kerja-praktek-1550498404585.firebaseapp.com",
    databaseURL: "https://kerja-praktek-1550498404585.firebaseio.com",
    projectId: "kerja-praktek-1550498404585",
    storageBucket: "kerja-praktek-1550498404585.appspot.com",
    messagingSenderId: "873471051525"
};
firebase.initializeApp(config);

app_fireBase = firebase;
})()