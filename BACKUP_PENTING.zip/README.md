Making of KP TM Online Website

Log<br />
**29/01/19**<br />
  *Using Bootstrap Pre-Build Layout<br />
**31/01/19**<br />
  *Forms and Upload pdf only File<br />
**31/01/19 Malam Hari**<br />
  *Attatch File navigation bar Panduan<br />
  *How to Center placeholders and buttons?<br />
  *How to change file input styles?
